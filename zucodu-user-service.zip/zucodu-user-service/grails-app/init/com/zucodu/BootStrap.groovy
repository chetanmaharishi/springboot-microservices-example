package com.zucodu


class BootStrap {


    def init = { servletContext ->
    }

    def destroy = {
    }
}

import com.zucodu.security.CustomUserDetailService

// Place your Spring DSL code here
beans = {
    userDetailsService(CustomUserDetailService)
}
